# EduTech Hub

An AI-powered personalized learning platform with localized curriculum.

## Local Development

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Backend
```bash
cd backend
npm install
node index.js
```

Backend runs at http://localhost:4000

## Docker Compose (with Postgres)
```bash
docker-compose up --build
```

## One-Click Deploy (preconfigured for this repo)

### Deploy Frontend (Vercel)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/its-phillip/edutech-hub-hackathon-3&project-name=edutech-hub&repository-name=edutech-hub-hackathon-3&root-directory=frontend&build-command=npm%20run%20build&output-directory=dist)

### Deploy Frontend (Netlify)
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/its-phillip/edutech-hub-hackathon-3)

### Deploy Backend (Render)
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)
