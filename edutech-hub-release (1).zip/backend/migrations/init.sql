CREATE TABLE IF NOT EXISTS contacts(
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT,
  message TEXT
);

CREATE TABLE IF NOT EXISTS enrolls(
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT,
  course TEXT
);
