const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const port = process.env.PORT || 4000;
const dbUrl = process.env.DATABASE_URL;
let pool;

if (dbUrl) {
  pool = new Pool({ connectionString: dbUrl, ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false });
}

// fallback JSON storage
const DATA_FILE = __dirname + '/data.json';

function saveData(type, payload) {
  let data = { contacts: [], enrolls: [] };
  if (fs.existsSync(DATA_FILE)) {
    data = JSON.parse(fs.readFileSync(DATA_FILE));
  }
  data[type].push(payload);
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/contact', async (req, res) => {
  const { name, email, message } = req.body;
  if (pool) {
    await pool.query('INSERT INTO contacts(name,email,message) VALUES($1,$2,$3)', [name, email, message]);
  } else {
    saveData('contacts', { name, email, message });
  }
  res.json({ success: true });
});

app.post('/api/enroll', async (req, res) => {
  const { name, email, course } = req.body;
  if (pool) {
    await pool.query('INSERT INTO enrolls(name,email,course) VALUES($1,$2,$3)', [name, email, course]);
  } else {
    saveData('enrolls', { name, email, course });
  }
  res.json({ success: true });
});

app.listen(port, () => console.log('Backend running on port ' + port));
