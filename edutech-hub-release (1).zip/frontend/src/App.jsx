const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

import React, { useState } from 'react';

function App() {
  const [message, setMessage] = useState('Welcome to EduTech Hub');

  const testApi = async () => {
    try {
      const res = await fetch(API_URL + '/api/health');
      const data = await res.json();
      alert('Backend says: ' + data.status);
    } catch (err) {
      alert('API error: ' + err.message);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <h1 className="text-4xl font-bold mb-4">{message}</h1>
      <button
        className="px-4 py-2 bg-blue-600 text-white rounded"
        onClick={testApi}
      >
        Test Backend Connection
      </button>
    </div>
  );
}

export default App;
